# Py3Aiml3ForChinese
Aiml (Python3版) 对中文的支持不好,  在这里做一些调整以支持中文. 持续更新中
